﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DropDownList1.Items.Add(new ListItem("NPTEL"));
                DropDownList1.Items.Add(new ListItem("Self Learning"));
                GridView1.Visible = false;
                GridView2.Visible = false;
            }
            
            
        }

       

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(DropDownList1.SelectedValue)
            {
                case "NPTEL":
                    GridView1.Visible = true;
                    GridView2.Visible = false;
                    break;

                case "Self Learning":
                    GridView1.Visible = false;
                    GridView2.Visible = true;
                    break;
            }
        }
    }
}