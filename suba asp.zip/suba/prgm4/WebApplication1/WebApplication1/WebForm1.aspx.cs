﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.Visible = false;
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            GridView1.Visible = true;

            if (FileUpload1.HasFile)
            {
                string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/picture/") + filename);
            }

            string[] filepaths = Directory.GetFiles(Server.MapPath("/picture/"));
            List<ListItem> files = new List<ListItem>();

            foreach (string filepath in filepaths)
            {
                string filename = Path.GetFileName(filepath);
                files.Add(new ListItem(filename, "~/picture/" + filename));
            }
            GridView1.DataSource = files;
            GridView1.DataBind();
        }
    }
}