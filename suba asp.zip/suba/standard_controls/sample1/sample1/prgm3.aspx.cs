﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sample1
{
    public partial class placeholder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListBox1.SelectedValue=="1")      
            {
                BulletedList1.Visible = true;
                BulletedList1.Items.Clear();
                ListItem i2 = new ListItem("Night Wear");
                ListItem i3 = new ListItem("Kurtis");
                ListItem i4 = new ListItem("Maternity Wear");
                BulletedList1.Items.Add(new ListItem("Sarees"));
                BulletedList1.Items.Add(i2);
                BulletedList1.Items.Add(i3);
                BulletedList1.Items.Add(i4);
            }

        }

        
    }
}