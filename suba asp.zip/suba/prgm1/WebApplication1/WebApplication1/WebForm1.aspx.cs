﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace prgm1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ListBox1.Items.Add("Cheese Cake");
                ListBox1.Items.Add("Dream Cake");
                ListBox1.Items.Add("Pinata Cake");
                ListBox1.Items.Add("Brownie");
            }
        }
        protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = ListBox1.SelectedIndex;
            if (i == 0)
            {
                ListImage1.ImageUrl = "~/img/cheese.jpg";
                ListImage1.AlternateText = "CHEESE CAKE";
            }
            else if (i == 1)
            {
                ListImage1.ImageUrl = "~/img/dream.jpg";
                ListImage1.AlternateText = "CHEESE CAKE";
            }
            else if (i == 2)
            {
                ListImage1.ImageUrl = "~/img/pinata.jpg";
                ListImage1.AlternateText = "PINATA CAKE";
            }
            else if (i == 3)
            {
                ListImage1.ImageUrl = "~/img/brownie.jpg";
                ListImage1.AlternateText = "BROWNIE CAKE";
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            int i = ListBox1.SelectedIndex;
            Label3.Text = "Item Selected is " + ListBox1.SelectedValue + " and its cost is ";
            if (i == 0)
            {
                Label3.Text += "150";
            }
            else if (i == 1)
            {
                Label3.Text += "230";
            }
            else if (i == 2)
            {
                Label3.Text += "300";
            }
            else if (i == 3)
            {
                Label3.Text += "170";
            }
        }
    }
}