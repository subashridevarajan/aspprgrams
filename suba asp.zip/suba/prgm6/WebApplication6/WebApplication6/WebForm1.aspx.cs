﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            double m1, m2, m3, avg = 0, total = 0;
            String name;
            name = (TextBox1.Text);
            m1 = Convert.ToDouble(TextBox2.Text);
            m2 = Convert.ToDouble(TextBox3.Text);
            m3 = Convert.ToDouble(TextBox4.Text);
            total = m1 + m2 + m3;
            TextBox5.Text = total.ToString();
            avg = total / 3;
            while (total > 0)
            {
                Label6.Text = "The Average of " + TextBox1.Text + " is : " + avg;
                total = 0;
                Label7.Text = "The " + TextBox1.Text + " Grade is : ";
                if (avg >= 75)
                {
                    Label7.Text += "Distinction";
                }
                else if (avg >= 60 && avg < 75)
                {
                    Label7.Text += "First Class";
                }
                else if (avg >= 50 && avg < 60)
                {
                    Label7.Text += "Second Class";
                }
                else if (avg >= 35 && avg < 50)
                {
                    Label7.Text += "PASS";
                }
                else
                {
                    Label7.Text += "FAIL";
                }
            }
        }
    }
}