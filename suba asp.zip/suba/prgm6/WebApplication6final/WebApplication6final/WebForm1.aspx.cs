﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6final
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DropDownList1.Items.Add("UG Courses");
                DropDownList1.Items.Add("B.Sc.CS");
                DropDownList1.Items.Add("B.Com.CA");
                DropDownList2.Items.Add("PG Courses");
                DropDownList2.Items.Add("M.Sc.CS");
                DropDownList2.Items.Add("M.Com.CA");
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedIndex == 1)
            {
                Label3.Text = "C-Programming";
                Label4.Text = "Python Programming";
                Label5.Text = "Operating System";
            }
            else if (DropDownList1.SelectedIndex == 2)
            {
                Label3.Text = "Financial Accounting";
                Label4.Text = "Professional Marketing";
                Label5.Text = "Tally";
            }
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList2.SelectedIndex == 1)
            {
                Label3.Text = "Java Programming";
                Label4.Text = "Big Data Analytics";
                Label5.Text = "Design Analysis";
            }
            else if (DropDownList2.SelectedIndex == 2)
            {
                Label3.Text = "Income Tax";
                Label4.Text = "E-Commerce";
                Label5.Text = "Statistics";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int m1, m2, m3, avg = 0, total = 0;
            String name;
            name = (TextBox4.Text);
            m1 = Convert.ToInt16(TextBox1.Text);
            m2 = Convert.ToInt16(TextBox2.Text);
            m3 = Convert.ToInt16(TextBox3.Text);
            total = m1 + m2 + m3;
            TextBox5.Text = "Total is " + total.ToString();
            avg = total / 3;
            if (m1 >= 30 && m2 >= 30 && m3 >= 30)
            {
                TextBox7.Text += "Pass";
                while (total > 0)
                {
                    TextBox6.Text = "Average " + avg;
                    total = 0;
                    TextBox7.Text = "Grade is ";
                    if (avg >= 75)
                    {
                        TextBox7.Text += "Distinction";
                    }
                    else if (avg >= 60 && avg < 75)
                    {
                        TextBox7.Text += "First Class";
                    }
                    else if (avg > 30 && avg < 60)
                    {
                        TextBox7.Text += "Second Class";
                    }
                }
            }
            else
            {
                TextBox7.Text += "Fail";
                TextBox6.Text = "Average = 0";
            }
        }


        
    }
}