﻿using System;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            // Retrieve inputs
            string name = txtName.Text;
            string studentClass = txtClass.Text;

            // Initialize variables
            int subject1 = 0, subject2 = 0, subject3 = 0;

            // Check if the inputs can be parsed to integers
            bool isValidInput = int.TryParse(txtSubject1.Text, out subject1) &&
                                int.TryParse(txtSubject2.Text, out subject2) &&
                                int.TryParse(txtSubject3.Text, out subject3);

            if (isValidInput)
            {
                // Calculate total, average, and grade
                int total = subject1 + subject2 + subject3;
                double average = total / 3.0;
                string grade = CalculateGrade(average);

                // Display results
                lblResult.Text =
                    "<h3>Student Result</h3>" +
                    "<table border='1'>" +
                    "<tr><td><strong>Name:</strong></td><td>" + name + "</td></tr>" +
                    "<tr><td><strong>Class:</strong></td><td>" + studentClass + "</td></tr>" +
                    "<tr><td><strong>Subject 1 Mark:</strong></td><td>" + subject1 + "</td></tr>" +
                    "<tr><td><strong>Subject 2 Mark:</strong></td><td>" + subject2 + "</td></tr>" +
                    "<tr><td><strong>Subject 3 Mark:</strong></td><td>" + subject3 + "</td></tr>" +
                    "<tr><td><strong>Total:</strong></td><td>" + total + "</td></tr>" +
                    "<tr><td><strong>Average:</strong></td><td>" + average.ToString("F2") + "</td></tr>" +
                    "<tr><td><strong>Grade:</strong></td><td>" + grade + "</td></tr>" +
                    "</table>";

                pnlResult.Visible = true;
            }
            else
            {
                lblResult.Text = "Please enter valid marks.";
                pnlResult.Visible = true;
            }
        }

        private string CalculateGrade(double average)
        {
            if (average >= 90)
                return "A";
            else if (average >= 80)
                return "B";
            else if (average >= 70)
                return "C";
            else if (average >= 60)
                return "D";
            else
                return "F";
        }
    }
}
