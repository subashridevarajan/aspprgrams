﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private string GetGrade(double average)
        {
            if (average >= 90) return "A";
            if (average >= 80) return "B";
            if (average >= 70) return "C";
            if (average >= 60) return "D";
            return "F";
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            // Retrieve input values
            string studentName = txtName.Text;
            int subject1, subject2, subject3;

            // Validate and parse input values
            if (int.TryParse(txtSubject1.Text, out subject1) &&
                int.TryParse(txtSubject2.Text, out subject2) &&
                int.TryParse(txtSubject3.Text, out subject3))
            {
                // Calculate total, average, and grade
                int total = subject1 + subject2 + subject3;
                double average = total / 3.0;
                string grade = GetGrade(average);

                // Create a DataTable to hold the results
                DataTable dt = new DataTable();
                dt.Columns.Add("Student Name");
                dt.Columns.Add("Subject 1 Mark");
                dt.Columns.Add("Subject 2 Mark");
                dt.Columns.Add("Subject 3 Mark");
                dt.Columns.Add("Total");
                dt.Columns.Add("Average");
                dt.Columns.Add("Grade");

                // Add a new row with the input values
                DataRow row = dt.NewRow();
                row["Student Name"] = studentName;
                row["Subject 1 Mark"] = subject1;
                row["Subject 2 Mark"] = subject2;
                row["Subject 3 Mark"] = subject3;
                row["Total"] = total;
                row["Average"] = average;
                row["Grade"] = grade;
                dt.Rows.Add(row);

                // Bind the DataTable to the GridView
                gvResults.DataSource = dt;
                gvResults.DataBind();
            }
            else
            {
                // Handle invalid input
                // For example, you might display an error message
                // lblError.Text = "Please enter valid marks.";
            }
        }

    }
}