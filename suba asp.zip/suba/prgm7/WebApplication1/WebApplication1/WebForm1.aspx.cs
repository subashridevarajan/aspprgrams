﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataList1.Visible = false;
                GridView1.Visible = false;
            }
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (RadioButtonList1.SelectedIndex == 0)
            {
                DataList1.Visible = true;
                GridView1.Visible = false;
            }
            if (RadioButtonList1.SelectedIndex == 1)
            {
                DataList1.Visible = false;
                GridView1.Visible = true;
            }
        }
    }
}