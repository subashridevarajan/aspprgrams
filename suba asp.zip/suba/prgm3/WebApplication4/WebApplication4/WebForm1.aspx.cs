﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                DropDownList1.Items.Add(new ListItem("Category"));
                DropDownList1.Items.Add(new ListItem("Womens Wear"));
                DropDownList1.Items.Add(new ListItem("Kids Wear"));
                DropDownList1.Items.Add(new ListItem("Mens Wear"));
            }
            Image1.ImageUrl = "~/pics/logo.jpg";
            
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedIndex == 1)
            {
                Image1.ImageUrl = "~/pics/w.jpg";
                BulletedList1.Visible = true;
                BulletedList1.Items.Clear();
                ListItem i2 = new ListItem("Night Wear");
                ListItem i3 = new ListItem("Kurtis");
                ListItem i4 = new ListItem("Maternity Wear");
                BulletedList1.Items.Add(new ListItem("Sarees"));
                BulletedList1.Items.Add(i2);
                BulletedList1.Items.Add(i3);
                BulletedList1.Items.Add(i4);
            }

            else if (DropDownList1.SelectedIndex == 2)
            {
                Image1.ImageUrl = "~/pics/k.jpg";
                BulletedList1.Visible = true;
                BulletedList1.Items.Clear();
                ListItem i2 = new ListItem("Tunics & Tops");
                ListItem i3 = new ListItem("Lehangas");
                ListItem i4 = new ListItem("Pinoform");
                BulletedList1.Items.Add(new ListItem("Skirts"));
                BulletedList1.Items.Add(i2);
                BulletedList1.Items.Add(i3);
                BulletedList1.Items.Add(i4);
            }

            else if (DropDownList1.SelectedIndex == 3)
            {
                Image1.ImageUrl = "~/pics/m.jpg";
                BulletedList1.Visible = true;
                BulletedList1.Items.Clear();
                ListItem i2 = new ListItem("Printed Shirts");
                ListItem i3 = new ListItem("Suits");
                ListItem i4 = new ListItem("Night Wears");
                BulletedList1.Items.Add(new ListItem("Formals"));
                BulletedList1.Items.Add(i2);
                BulletedList1.Items.Add(i3);
                BulletedList1.Items.Add(i4);
            }
        }
    }
}